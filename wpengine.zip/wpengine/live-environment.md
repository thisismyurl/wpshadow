# WP Engine Live Environment

This repository can connect directly to the WP Engine live environment below.

## Environment

- Label: `live`
- SFTP host: `thisismyurlcom.sftp.wpengine.com`
- Port: `2222`

## Local Credentials

- Local credentials file: `.env.wpengine-live` (gitignored)

## Notes

- This tracked file intentionally excludes the live password.
- Use the local env file for direct SFTP or deployment automation from the Codespace.