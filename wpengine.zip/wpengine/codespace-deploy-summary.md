# WP Engine Deployment Summary for Codespaces

This guide is the portable checklist to connect and deploy from a fresh Codespace to WP Engine dev and live.

## 1) One-Time Codespace Setup

Run this first to install trusted host keys used by this repo:

```bash
bash repo-tools/wpengine/setup-known-hosts.sh
```

Reference files:
- `repo-tools/wpengine/known_hosts`
- `repo-tools/wpengine/setup-known-hosts.sh`

## 2) Local Env Files (Required)

These files are local secrets and should stay gitignored.

### Dev env file: `.env.wpengine-dev`

```bash
WPENGINE_ENV=dev
WPENGINE_SITE_URL=http://thisismyurldev.wpenginepowered.com/
WPENGINE_SFTP_HOST=thisismyurldev.sftp.wpengine.com
WPENGINE_SFTP_USERNAME=thisismyurldev-github
WPENGINE_SFTP_PASSWORD='M0galF!sh'
WPENGINE_BASIC_AUTH_USER=thisismyurldev
WPENGINE_BASIC_AUTH_PASSWORD=9460b137
WPENGINE_SSH_HOST_KEY_ALGORITHM=ssh-ed25519
WPENGINE_SSH_HOST_KEY=AAAAC3NzaC1lZDI1NTE5AAAAIC2qNDXXHN2kYJe9wQ5eq1TPfdE4nX5swjVcqCmFQGQh
```

### Live env file: `.env.wpengine-live`

```bash
WPENGINE_ENV=live
WPENGINE_SITE_URL=https://thisismyurl.com/
WPENGINE_SFTP_HOST=thisismyurlcom.sftp.wpengine.com
WPENGINE_SFTP_PORT=2222
WPENGINE_SFTP_USERNAME=<live-sftp-username>
WPENGINE_SFTP_PASSWORD='<live-sftp-password>'
```

## 3) Quick Connectivity Tests

### Dev SFTP auth test

```bash
source .env.wpengine-dev
sshpass -p "$WPENGINE_SFTP_PASSWORD" sftp -o Port=2222 -o StrictHostKeyChecking=no "$WPENGINE_SFTP_USERNAME@$WPENGINE_SFTP_HOST" <<< "ls"
```

### Dev protected-site auth test

```bash
source .env.wpengine-dev
curl -s -o /tmp/dev_home_check.html -w "%{http_code}\n" \
  -u "$WPENGINE_BASIC_AUTH_USER:$WPENGINE_BASIC_AUTH_PASSWORD" \
  "$WPENGINE_SITE_URL"
```

Expected result: `200`.

### Live SFTP auth test

```bash
source .env.wpengine-live
sshpass -p "$WPENGINE_SFTP_PASSWORD" sftp -o Port="${WPENGINE_SFTP_PORT:-2222}" -o StrictHostKeyChecking=no "$WPENGINE_SFTP_USERNAME@$WPENGINE_SFTP_HOST" <<< "ls"
```

## 4) Dev Deployment (Repo Standard)

Primary script:

```bash
bash deploy_and_verify_files.sh
```

What it does:
- Uploads key changed files to dev via SFTP.
- Runs page verification checks using dev HTTP basic auth.

Note: this script sources `.env.wpengine-dev` internally, so keep that file current.

## 5) Live Deployment (Manual SFTP Pattern)

Use this pattern when deploying selected files to live:

```bash
source .env.wpengine-live
cat > /tmp/sftp_live_batch.txt <<'SFTP_EOF'
put wp-content/themes/thisismyurl-2026/assets/css/main.css wp-content/themes/thisismyurl-2026/assets/css/main.css
# Add more put lines as needed
quit
SFTP_EOF

sshpass -p "$WPENGINE_SFTP_PASSWORD" \
  sftp -P "${WPENGINE_SFTP_PORT:-2222}" \
  -o StrictHostKeyChecking=no \
  "$WPENGINE_SFTP_USERNAME@$WPENGINE_SFTP_HOST" < /tmp/sftp_live_batch.txt

rm -f /tmp/sftp_live_batch.txt
```

## 6) Important Gotchas (Already Hit in This Repo)

- If you see `Permission denied (password,publickey,keyboard-interactive)`, first verify host, username, and password in the relevant env file.
- For password-based auth with `sshpass`, prefer stdin redirection:
  - Good: `sftp ... < sftp_batch.txt`
  - Risky: `sftp -b sftp_batch.txt ...` (batch mode can trigger non-interactive auth behavior that rejects password flow).
- Do not rely on temporary shell overrides when a script does `source .env...`; sourced values can override what you exported.

## 7) Minimal Handoff Checklist for Another Codespace

- Clone repo.
- Create `.env.wpengine-dev` and `.env.wpengine-live` with current credentials.
- Run `bash repo-tools/wpengine/setup-known-hosts.sh`.
- Run SFTP auth test(s).
- Run `bash deploy_and_verify_files.sh` for dev deployments.
- For live, run manual SFTP batch pattern above.
