# WP Engine Dev Environment

This repository is connected to the WP Engine development test environment below.

## Environment

- Label: `dev`
- Web URL: `http://thisismyurldev.wpenginepowered.com/`

## SSH Host Key

Use this host key when trusting the WP Engine development environment from a Codespace or other remote shell:

```text
thisismyurldev.wpenginepowered.com ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIC2qNDXXHN2kYJe9wQ5eq1TPfdE4nX5swjVcqCmFQGQh
```

## Repo Assets

- Known-hosts entry: `repo-tools/wpengine/known_hosts`
- Install script: `repo-tools/wpengine/setup-known-hosts.sh`
- Local credentials file: `.env.wpengine-dev` (gitignored)

## Notes

- This file stores the environment details so they remain available inside the repository.
- If the WP Engine SSH username, Git remote, or rsync endpoint changes, update this file and the related helper assets at the same time.